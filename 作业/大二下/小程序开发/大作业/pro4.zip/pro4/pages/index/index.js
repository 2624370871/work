// index.js

Page({
  data: {
  },
  // 事件处理函数
  inputName(e){
    this.name=e.detail.value;
    },
    inputPhone(e){
    this.phone=e.detail.value;
    },
    makeCall(){
      wx.makePhoneCall({
        phoneNumber:this.phone
      }).catch((e) => {
      })
    }
})
