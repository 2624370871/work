

Page({
  data: {
    
  },
  // 事件处理函数
 
})
