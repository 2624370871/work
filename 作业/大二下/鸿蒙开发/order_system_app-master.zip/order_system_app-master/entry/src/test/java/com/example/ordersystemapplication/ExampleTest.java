package com.example.ordersystemapplication;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
